<template>
    <nav>
        <v-toolbar app flat >
            <v-toolbar-title class="text-uppercase ">
                <span class="font-weight-light grey--text">Fight</span>
                <span> Corona</span>
            </v-toolbar-title>

            <v-spacer></v-spacer>

            <v-btn flat depressed>
                <!-- <a href="https://geojson.in/" target="_blank" rel="noopener">Live updates</a> -->
                <a style="text-decoration:none; color:inherit;" href="https://geojson.in/" >Live Stats</a>
                <v-icon right >mdi-update</v-icon>
            </v-btn>
        </v-toolbar>
    </nav>
</template>

<script>
export default {
    
}
</script>

