<template>
  <div class="about">
    <section>
      <iframe width="560" height="315" src="https://www.youtube.com/embed/3Uugj-zxA5E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
    </section>

    



  </div>
</template>
